package com.example;

import java.io.File;

import javax.print.Doc;
import javax.xml.parsers.*;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class Main {
    public static void main(String[] args) throws Exception {
        String filepath = "biblioteca.xml";
        // Crear toda la parafernalia para tratar un documento XML
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new File(filepath));

        // Normalizo el xml, para que no de problemas
        doc.getDocumentElement().normalize();

        // Obtengo los elementos de etiqueta libro
        NodeList listaLibros = doc.getElementsByTagName("libro");

        leerXML(listaLibros);
        System.out.println("----------------------");

        // Obtengo primero, un array de nodos, solo con biblioteca, luego saco el primer elemento, 
        // que es la biblioteca, lo transformo a Elemento del otro import y lo manejo
        Element biblioteca = (Element) doc.getElementsByTagName("biblioteca");

        // Creo un nuevo libro
        Element newLibro = doc.createElement("libro");
        // Le agrego una subetiqueta de titulo, autor y año
        newLibro.appendChild(doc.createElement("titulo")).appendChild(doc.createTextNode("El Señor de los Anillos"));
        newLibro.appendChild(doc.createElement("autor")).appendChild(doc.createTextNode("J.R.R. Tolkien"));
        newLibro.appendChild(doc.createElement("año")).appendChild(doc.createTextNode("1954"));
        // Y lo meto en el elemento biblioteca recogido del xml antes
        biblioteca.appendChild(newLibro);

        // Aqui vuelvo a transformar el xml con el nuevo libro // entiendo lo que hace pero wtf
        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        // bueno aqui ya locura
        // Primero de donde lo cojemos y luego donde va
        transformer.transform(new DOMSource(doc), new StreamResult(new File("biblioteca2.xml")));

        // se repite el proceso para mostrar el nuevo xml
        filepath = "biblioteca2.xml";
        DocumentBuilderFactory factory1 = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder1 = factory1.newDocumentBuilder();
        Document doc1 = builder1.parse(new File(filepath));

        doc1.getDocumentElement().normalize();

        NodeList libros1 = doc1.getElementsByTagName("libro");

        leerXML(libros1);
    }

    static void leerXML(NodeList libros) {
        // le paso un array de nodos libros
        for (int i = 0; i < libros.getLength(); i++) {
            Element libro = (Element) libros.item(i);
            // Para titulo, autor y año, saco un array de nodos de dentro de libro con cada uno, 
            // saco el primer el elemento ya que solo hay uno y devuelvo el contenido
            String title = libro.getElementsByTagName("titulo").item(0).getTextContent();
            String author = libro.getElementsByTagName("autor").item(0).getTextContent();
            String year = libro.getElementsByTagName("año").item(0).getTextContent();
            // Se pone bonito y se imprime
            System.out.println(title + " by " + author + " (" + year + ")");
        }
    }

    static void leerXML2(NodeList libros) {
        // le paso un array de nodos libros
        for (int i = 0; i < libros.getLength(); i++) {
            Node nodoLibro = libros.item(i);

            // Se comprueba si es un elemento válido
            if (nodoLibro.getNodeType() == Node.ELEMENT_NODE) {
                Element libro = (Element) nodoLibro;
                String title = libro.getElementsByTagName("titulo").item(0).getTextContent();
                String author = libro.getElementsByTagName("autor").item(0).getTextContent();
                String year = libro.getElementsByTagName("año").item(0).getTextContent();
                // Se pone bonito y se imprime
                System.out.println(title + " by " + author + " (" + year + ")");
            }

        }
    }
}