CREATE DATABASE inventario;
